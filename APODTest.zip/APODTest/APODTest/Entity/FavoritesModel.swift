//
//  FavoritesModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
class FavoritesModel: Object {
    @objc dynamic var title: String = ""
    @objc dynamic var copyright : String = ""
    @objc dynamic var date: String = ""
    @objc dynamic var explanation: String = ""
    @objc dynamic var hdurl: String = ""
    @objc dynamic var mediaType : String = ""
    @objc dynamic var serviceVersion: String = ""
    @objc dynamic var url : String = ""
}
