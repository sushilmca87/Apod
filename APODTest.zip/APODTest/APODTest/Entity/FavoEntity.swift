//
//  FavoEntity.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
protocol RealmEntity {
    associatedtype ModelType
    var modelObject: ModelType { get }
}
protocol Entity {
    associatedtype RealmEntityType
    var realmObject: RealmEntityType { get }
}
class FavoEntity: Object,RealmEntity {
    typealias ModelType = FavoModel
    dynamic var title: String?
    dynamic var copyright : String?
    dynamic var date: String?
    dynamic var explanation: String?
    dynamic var hdurl: String?
    dynamic var mediaType : String?
    dynamic var serviceVersion: String?
    dynamic var url : String?
    var modelObject: FavoModel {
        return FavoModel(favoEntity: self)
    }
}
extension FavoEntity {
    convenience init(model: ModelType) {
        self.init()
        self.title = model.title ?? self.title
        self.copyright = model.copyright ?? self.copyright
        self.date = model.date ?? self.date
        self.explanation = model.explanation ?? self.explanation
        self.hdurl = model.hdurl ?? self.hdurl
        self.mediaType = model.mediaType ?? self.mediaType
        self.serviceVersion = model.serviceVersion ?? self.serviceVersion
        self.url = model.url ?? self.url
    }

}
