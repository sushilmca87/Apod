//
//  FavoModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
class FavoModel: Entity {
    typealias RealmEntityType = FavoEntity
    dynamic  var title: String?
    dynamic var copyright : String?
    dynamic var date: String?
    dynamic var explanation: String?
    dynamic var hdurl: String?
    dynamic var mediaType : String?
    dynamic var serviceVersion: String?
    dynamic var url : String?
    init() {}
    init(favoEntity:RealmEntityType) {
        self.title = favoEntity.title
        self.copyright = favoEntity.copyright
        self.date = favoEntity.date
        self.explanation = favoEntity.explanation
        self.hdurl = favoEntity.hdurl
        self.mediaType = favoEntity.mediaType
        self.serviceVersion = favoEntity.serviceVersion
        self.url = favoEntity.url
    }
    var realmObject: FavoEntity {
        return FavoEntity(model: self)
    }
}
