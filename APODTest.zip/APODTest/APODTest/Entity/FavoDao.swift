//
//  FavoDao.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 22/01/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import RealmSwift
struct FavoriteDao {
    dynamic  var title: String?
    dynamic var copyright : String?
    dynamic var date: String?
    dynamic var explanation: String?
    dynamic var hdurl: String?
    dynamic var mediaType : String?
    dynamic var serviceVersion: String?
    dynamic var url : String?
    public init() {}
    func saveApodInfo(apod: Apod){
        let realm = try? Realm()
        let favorites = realm?.objects(FavoritesModel.self).filter("date contains[c] %@",apod.date ?? "")
        if let value = favorites?.first {
            print("record found value:\(value)")
            self.deleted(object: value)
            self.saveApodInfo(apod: apod)
        }else{
            let favo = FavoritesModel()
            favo.title = apod.title ?? ""
            favo.copyright = apod.copyright ?? ""
            favo.date = apod.date ?? ""
            favo.explanation = apod.explanation ?? ""
            favo.hdurl = apod.hdurl ?? ""
            favo.mediaType = apod.mediaType ?? ""
            favo.serviceVersion = apod.serviceVersion ?? ""
            favo.url = apod.url ?? ""
            try? realm?.write {
                realm?.add(favo)
            }
        }
    }
    func deleted(object:Object){
        let realm = try! Realm()
        try? realm.write {
            print("deleted word: \(object)")
            realm.delete(object)
        }
    }
    func fetchFavorites(apod: Apod)-> FavoritesModel?{
        let realm = try? Realm()
        let favorites = realm?.objects(FavoritesModel.self).filter("date contains[c] %@",apod.date ?? "")
        if let value = favorites?.first {
            print("record found value:\(value)")
            return value
        }
        return nil
    }
    func deleteFavorites(apod: Apod){
        let realm = try? Realm()
        let favorites = realm?.objects(FavoritesModel.self).filter("date contains[c] %@",apod.date ?? "")
        if let value = favorites?.first {
            print("record found value:\(value)")
            self.deleted(object: value)
        }
    }
    func fetchAllFavorites() -> [FavoritesModel]{
        let realm = try? Realm()
        var models:[FavoritesModel] = []
        let favorites = realm?.objects(FavoritesModel.self)
        favorites?.forEach { (model) in
            models.insert(model, at: 0)
        }
        print("models:\(models.count)")
        return models
    }
}
