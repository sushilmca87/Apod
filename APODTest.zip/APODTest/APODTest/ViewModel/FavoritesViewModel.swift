//
//  FavoritesModel.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 14/02/22.
//

import Foundation
final class FavoritesViewModel {
    var bindApods:((_ apods:[FavoritesModel]?) -> ())?
    private var favoritesDao: FavoriteDao?
    private (set) var apods:[FavoritesModel] = []
    init(){
        favoritesDao = FavoriteDao()
    }
    func fetchAllApods(){
        self.apods = favoritesDao?.fetchAllFavorites() ?? []
        self.bindApods?(apods)
    }
}

