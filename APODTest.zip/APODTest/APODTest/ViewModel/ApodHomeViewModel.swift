//
//  ApodHomeViewModel.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 12/02/22.
//

import Foundation
import Combine

class ApodHomeViewModel  {
    private var apiService: WebServiceRequestProtocol
    private (set) var apod: Apod?
    private var store = Set<AnyCancellable>()
    var bindApodDetails:((_ apod:Apod) -> ())?
    var bindApodImage:((_ data: Data) -> ())?
    private var favoritesDao: FavoriteDao?
    init() {
        apiService = ApodService()
        favoritesDao = FavoriteDao()
    }
    func fetchApod(withDate date: String) {
        apiService.fetchApod(withDate: date).sink { Completion in
            switch Completion{
            case .finished:
                print("finished")
            case .failure(let error):
                print("error:\(error)")
            }
        } receiveValue: {[weak self] apod in
            self?.apod = apod
            self?.bindApodDetails?(apod)
        }.store(in: &store)
    }
    func fetchApodImage(name: String) {
        apiService.fetchApodImage(withImageName: name).sink { Completion in
            switch Completion {
            case .finished:
                print("finished")
            case .failure(let error):
                print("error:\(error)")
            }
        } receiveValue: { [weak self] data  in
            self?.bindApodImage?(data)
        }.store(in: &store)
    }
    func saveAsFavorites(){
        if let apodInfo = apod, apodInfo.date != nil {
            favoritesDao?.saveApodInfo(apod: apodInfo)
        }
    }
    func deleteFromFavorites(){
        if let apodInfo = apod {
            favoritesDao?.deleteFavorites(apod: apodInfo)
        }
    }
    func isFavorites()->Bool{
        guard let apodInfo = apod else { return false}
        if  favoritesDao?.fetchFavorites(apod: apodInfo) == nil {
            return false
        }else {
            return true
        }
    }
}
