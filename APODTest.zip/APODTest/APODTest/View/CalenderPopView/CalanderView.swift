//
//  PopUpUiView.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 13/02/22.
//

import UIKit

class CalanderView: UIView {
    var dateSelected:((Date)->(Void))?
     override init(frame: CGRect) {
        super.init(frame: frame)
         self.backgroundColor = UIColor.BgColor
         self.addSubview(calendarPopup)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private lazy var calendarPopup: CalendarPopUpView = {
        let frame = CGRect(
            x: 15,
            y: 60.0,
            width: self.frame.width - 30,
            height: 365
        )
        let calendar = CalendarPopUpView(frame: frame)
        calendar.backgroundColor = UIColor.clear
        calendar.layer.shadowColor = UIColor.black.cgColor
        calendar.layer.shadowOpacity = 0.4
        calendar.layer.shadowOffset = CGSize.zero
        calendar.layer.shadowRadius = 5
        calendar.didSelectDay = { [weak self] date in
            self?.setSelectedDate(date)
        }
        return calendar
    }()
    private func setSelectedDate(_ date: Date) {
        self.dateSelected?(date)
    }
}
