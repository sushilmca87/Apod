//
//  CollectionViewCell.swift
//  LoadMoreExample
//
//  Created by Sushil Kumar Singh on 12/02/22.


import UIKit

class CollectionViewItemCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var activityIndecater: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    func configureCell(apod:FavoritesModel){
        self.titleLabel.text = apod.title
        let url = URL(string: apod.url)
        activityIndecater.startAnimating()
        self.imageView.sd_setImage(with: url) {[weak self] image, error, _, _ in
            self?.activityIndecater.stopAnimating()
            self?.activityIndecater.isHidden = true
        }
    }
}
