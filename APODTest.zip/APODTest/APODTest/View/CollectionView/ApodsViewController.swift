//
//  CollectionView.swift
//  LoadMoreExample
//
//  Created by Sushil Kumar Singh on 12/02/22.
//

import UIKit

class ApodsViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var viewModel: FavoritesViewModel!
    var isLoading = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        //Register Item Cell
        let itemCellNib = UINib(nibName: "CollectionViewItemCell", bundle: nil)
        self.collectionView.register(itemCellNib, forCellWithReuseIdentifier: "collectionviewitemcellid")
        viewModel = FavoritesViewModel()
        viewModel.fetchAllApods()
        self.collectionView.reloadData()
        let width = (view.frame.width-20)/2
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width)
        self.navigationController?.navigationItem.titleView?.tintColor = UIColor.white
        loadData()
    }
    func loadData() {
        collectionView.collectionViewLayout.invalidateLayout()
        viewModel.bindApods = {[weak self] apods in
            self?.collectionView.reloadData()
        }
    }
}
extension ApodsViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.apods.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionviewitemcellid", for: indexPath) as! CollectionViewItemCell
        let apod = viewModel.apods[indexPath.row]
        cell.configureCell(apod: apod)
        print("apod:\(apod.title)")
        return cell
    }
}
