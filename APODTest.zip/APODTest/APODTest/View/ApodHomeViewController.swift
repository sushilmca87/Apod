//
//  ApodHomeViewController.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 13/02/22
//

import UIKit
import SDWebImage
import VACalendar
class ApodHomeViewController: UIViewController {
    @IBOutlet weak var imageView:UIImageView!
    @IBOutlet weak var favoBtn: UIBarButtonItem!
    @IBOutlet weak var calenderBtn: UIBarButtonItem!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var detaileLabel: UITextView!
    @IBOutlet weak var activityIndecater: UIActivityIndicatorView!
    var viewModel: ApodHomeViewModel!
    var calenderView: CalanderView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleLable.text = ""
        self.detaileLabel.text = ""
        viewModel = ApodHomeViewModel()
        self.bindApodDetails()
        self.calendarPopup()
        setSelectedDate(Date())
        // Do any additional setup after loading the view.
    }
    func calendarPopup(){
        calenderView = CalanderView(frame: CGRect(x: 15, y: 0, width: Int(self.view.bounds.size.width) - 30, height: Constant.CalanderSize.height))
        calenderView.dateSelected = { [weak self] date in
            self?.navigationItem.title = DateFormatter.dayFormatter.string(from: date)
            let dateStr = DateFormatter.dateFormatter.string(from: date)
            self?.fetchAndUpdate(date: dateStr)
            self?.calenderBtn.isSelected = false
            self?.calenderView.removeFromSuperview()

        }
    }
    override func viewDidAppear(_ animated: Bool) {
        self.detaileLabel.sizeToFit()
        self.detaileLabel.clipsToBounds = true
    }
    override func viewDidLayoutSubviews() {
        let c = stackView.heightAnchor.constraint(equalTo: scrollView.heightAnchor)
        c.priority = UILayoutPriority(rawValue: 750)
        c.isActive = true
    }

    func fetchAndUpdate(date: String){
        activityIndecater.isHidden = false
        activityIndecater.startAnimating()
        viewModel.fetchApod(withDate: date)
    }
    func bindApodDetails(){
        viewModel.bindApodDetails =  {[weak self] apod in
            self?.titleLable.text = apod.title
            self?.detaileLabel.text = apod.explanation
            let url = URL(string: apod.url ?? "")
            let isFavorites = self?.viewModel.isFavorites() ?? false
            print("IsFavorites:\(isFavorites)")
            self?.favoBtn.isSelected = isFavorites
            self?.imageView.sd_setImage(with: url, completed: { iamge, error, _, _ in
                self?.activityIndecater.stopAnimating()
                self?.activityIndecater.isHidden = true
            })
        }
    }
    private func setSelectedDate(_ date: Date) {
        self.navigationItem.title = DateFormatter.dayFormatter.string(from: date)
        calenderView.removeFromSuperview()
        let date = DateFormatter.dateFormatter.string(from: date)
        fetchAndUpdate(date: date)
    }
    @IBAction func gotoFavoAction(_ sender: Any) {

    }
    @IBAction func calander(_ sender: UIBarButtonItem) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            view.addSubview(calenderView)
        } else {
            calenderView.removeFromSuperview()
        }
    }
    @IBAction func favo(_ sender: Any) {
        favoBtn.isSelected = !favoBtn.isSelected
        if favoBtn.isSelected {
            viewModel.saveAsFavorites()
        }else {
            viewModel.deleteFromFavorites()
        }

    }
}
