//
//  Constant.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 13/02/22.
//

import Foundation
import UIKit
struct Constant {
    struct CalanderSize {
        static let height = 365
    }

}
