//
//  UIColor+Color.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 13/02/22.
//

import Foundation
import UIKit
extension UIColor {
   static var BgColor: UIColor {
       return  UIColor(
            red: 240 / 255,
            green: 240 / 255,
            blue: 240 / 255,
            alpha: 1.0
            )
    }
}
