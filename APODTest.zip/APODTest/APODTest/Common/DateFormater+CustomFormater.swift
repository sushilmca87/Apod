//
//  DateFormater.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 13/02/22.
//
import Foundation
extension DateFormatter {
    static var dayFormatter: DateFormatter {
        let formater =  DateFormatter()
        formater.dateFormat = "E dd LLLL"
        return formater
    }
    static var dateFormatter: DateFormatter  {
        let formater =  DateFormatter()
        formater.dateFormat = "YYYY-MM-dd"
        return formater
    }
}
