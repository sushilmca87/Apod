//
//  Apod.swift
//  APODTest
//
//  Created by Sushil Kumar Singh on 12/02/22.
//

import Foundation
struct Apod: Decodable {
    var title: String?
    var copyright : String?
    var date: String?
    var explanation: String?
    var hdurl: String?
    var mediaType : String?
    var serviceVersion: String?
    var url : String?
    enum CodingKeys: String, CodingKey {
        case title = "title"
        case copyright = "copyright"
        case date = "date"
        case explanation = "explanation"
        case hdurl = "hdurl"
        case mediaType = "media_type"
        case serviceVersion = "service_version"
        case url = "url"
    }
}
