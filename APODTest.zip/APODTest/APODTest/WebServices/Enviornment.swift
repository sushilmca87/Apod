//
//  Enviornment.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
protocol EnvironmentDetails{
    var baseUrl:String {get}
    var subUrl: String {get}
    var token: String  {get}
}
enum ServerType : String, CustomDebugStringConvertible{
    case provisionURL =  "Provisional"
    case productionURL = "Production"
    
    var description:String {
        return self.rawValue
    }
    var debugDescription: String {
        return "\(self.rawValue)"
    }
}
struct EnviornmentInfo : EnvironmentDetails  {
    let environment:ServerType
    var baseUrl: String {
        switch environment {
        case .provisionURL:
            return "https://api.nasa.gov/planetary/apod?"
        case .productionURL:
            return "https://api.nasa.gov/planetary/apod?"
        }
    }
    var subUrl: String{
        switch environment {
        case .provisionURL:
            return "https://api.nasa.gov/planetary/apod?"
        case .productionURL:
            return "https://api.nasa.gov/planetary/apod?"
        }
    }
    var token: String {
        switch environment {
        case .provisionURL:
            return "api_key=Cla3tg8QOJ7gRd6d81nyDSqo7KWWb2JWuN39ub4s"
        case .productionURL:
            return "api_key=Cla3tg8QOJ7gRd6d81nyDSqo7KWWb2JWuN39ub4s"
        }
    }
}
