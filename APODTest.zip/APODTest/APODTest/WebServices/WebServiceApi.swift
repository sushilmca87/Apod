//
//  WebServiceApi.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
enum WebServiceHTTPApi : HttpApiProtocol {
    case fetchApod(date: String)
    case fetchApodImage(name: String)
    var path: String {
        switch self {
        case .fetchApod(let date):
            return "&date=\(date)"
        case .fetchApodImage(let name):
            return "image/2202/=\(name)"
        }
    }
    var method: String {
        switch self {
        case .fetchApod(_):
            return HttpMethod.GET.rawValue
        case .fetchApodImage(_):
            return HttpMethod.GET.rawValue
        }
    }
    var header: HttpHeaders {
        var headers = HttpHeaders([])
        switch self {
        case .fetchApod:
            headers.add(name: "", value: "")
        case .fetchApodImage(_):
            headers.add(name: "", value: "")
        }
        return headers
    }
    var parameter: String? {
        switch self {
        case .fetchApod(_):
            return nil
        case .fetchApodImage(_):
            return nil
        }
    }
    var body: Data?{
        switch self {
        case .fetchApod(_):
            return nil
        case .fetchApodImage(_):
            return nil
        }
    }
    var logKey:String? {
        switch self {
        case .fetchApod(let date):
            return "fetch App Pod Details with date:\(date)"
        case .fetchApodImage(let imageName):
            return "fetch app pod image with name:\(imageName)"
        }
    }
    var serverType:BaseUrl {
        return BaseUrl.provision
    }

}

