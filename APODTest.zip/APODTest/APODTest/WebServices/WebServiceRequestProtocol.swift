//
//  WebServiceRequestProtocol.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
import  Combine
protocol WebServiceRequestProtocol {
    func fetchApod(withDate date:String) -> Future<Apod, Failure>
    func fetchApodImage(withImageName  name:String)->Future<Data, Failure>
}
