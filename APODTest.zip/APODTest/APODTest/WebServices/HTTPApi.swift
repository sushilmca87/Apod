//
//  HTTPApi.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//
import Foundation
enum BaseUrl {
    case provision
    case production
}
protocol HttpApiProtocol {
    var path: String {get}
    var method: String {get}
    var header: HttpHeaders {get}
    var body: Data? {get}
    var parameter:String? {get}
    var logKey:String? {get}
    var serverType: BaseUrl {get}
}
enum HttpMethod : String{
    case GET = "GET"
    case POST = "POST"
    case DELETE = "DELETE"
    var description: String{
        switch self {
        case .GET:
            return "GET"
        case .POST:
            return "Post"
        case .DELETE:
            return "DELETE"
        }
    }
}
