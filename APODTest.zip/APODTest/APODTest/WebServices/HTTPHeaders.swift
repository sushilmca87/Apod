//
//  HTTPHeaders.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation
struct HTTPHeader {
    var name:String
    var value:String
}
struct HttpHeaders  {
    private var headers:[HTTPHeader] = []
    var name:String
    var value: String
    private init() {
        self.name = ""
        self.value = ""
    }
    public init(_ headers:[HTTPHeader]) {
        self.init()
        self.headers = headers
    }
    mutating  func add(name:String, value:String){
        let header = HTTPHeader(name: name, value: value)
        self.headers.append(header)
    }
    mutating func update(name:String, value:String){
        guard let index = headers.indexOf(name: name) else {
            headers.append(HTTPHeader(name: name, value: value))
            return
        }
        headers[index] = HTTPHeader(name: name, value: value)
    }
}
extension Array where Element == HTTPHeader {
    func indexOf(name:String) ->Int? {
        return firstIndex { $0.name.lowercased() == name.lowercased() }
    }
}
