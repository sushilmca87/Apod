//
//  SearchTrainService.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//

import UIKit
import Combine
enum Failure :Error  {
    case NetworkNotReachable
    case FoundNil
}
final class ApodService : WebServiceRequestProtocol {
    private var store = Set<AnyCancellable>()
    func fetchApod(withDate date: String) -> Future<Apod, Failure> {
        return Future { promises in
            let webServices = WebServices(serverType: .productionURL)
            let apiCall = WebServiceHTTPApi.fetchApod(date: date)
            webServices.requestApi(httpApi: apiCall)
                .receive(on: DispatchQueue.main)
                .sink { completion in
                    switch completion {
                    case .finished:
                        print("Finish")
                    case .failure(let error):
                        print("Failed:\(error)")
                        promises(.failure(Failure.FoundNil))
                    }
                } receiveValue: { data in
                    do {
                        if let apodData = data {
                            let apod = try JSONDecoder().decode(Apod.self, from: apodData)
                            promises(.success(apod))
                        }else {
                            promises(.failure(Failure.FoundNil))
                        }
                    }catch {
                        promises(.failure(Failure.FoundNil))
                    }
                }.store(in: &self.store)
        }
    }
    func fetchApodImage(withImageName name: String) -> Future<Data, Failure> {
        return Future { promises in
            let webServices = WebServices(serverType: .productionURL)
            let apiCall = WebServiceHTTPApi.fetchApodImage(name: name)
            webServices.requestApi(httpApi: apiCall)
                .receive(on: DispatchQueue.main)
                .sink { completion in
                    switch completion {
                    case .finished:
                        print("Finish")
                    case .failure(let error):
                        print("Failed:\(error)")
                        promises(.failure(Failure.FoundNil))
                    }
                } receiveValue: { data in
                    if let loData = data {
                        promises(.success(loData))
                    }else {
                        promises(.failure(Failure.FoundNil))
                    }
                }.store(in: &self.store)
        }
    }
}
