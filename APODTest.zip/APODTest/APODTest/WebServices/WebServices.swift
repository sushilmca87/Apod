//
//  WebServices.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 12/02/22
//  Copyright © 2022 Sample. All rights reserved.
//
import Foundation
import Combine
var store = Set<AnyCancellable>()

class WebServices  {
    typealias Element = Data
    private (set) var enviornment: EnviornmentInfo
    private lazy var session: URLSession = {
        // Create URL Session Configuration
        let configuration = URLSessionConfiguration.default
        // Define Request Cache Policy
        configuration.requestCachePolicy = .returnCacheDataElseLoad
        return URLSession(configuration: configuration)
    }()
    init(serverType: ServerType) {
        enviornment = EnviornmentInfo(environment: serverType)
    }
    func requestApi(httpApi:WebServiceHTTPApi) -> Future<Element?, Never>{
        return Future { [self] promises in
            let loUrl = self.getFullUrl(apiCall: httpApi)
            print("loUrl:\(loUrl)")
            guard let url = URL(string: loUrl) else  {
                return
            }
            session.dataTaskPublisher(for: url)
                .sink { completion in
                    switch completion{
                    case .finished:
                        print("completed")
                    case .failure(_):
                        promises(.success(nil))
                        break
                    }
                } receiveValue: { (data, response) in
                    print("response1111:\(response)")
                    promises(.success(data))
                }
                .store(in: &store)
        }
    }
}
extension WebServices {
    func getFullUrl(apiCall:HttpApiProtocol) ->String{
        switch apiCall.serverType {
        case .provision:
            return (self.enviornment.baseUrl  + self.enviornment.token  + apiCall.path)
        case .production:
            return (self.enviornment.baseUrl  + self.enviornment.token + apiCall.path)
        }
    }
}

